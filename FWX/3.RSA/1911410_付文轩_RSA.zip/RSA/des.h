#pragma once
#include<iostream>
#include<string>
#include<bitset>

int encryptForRSA(int, int);